import logo from './logo.svg';
import './App.css';
import RestaurantDetails from './Restaurent Details/RestaurantDetails'
function App() {
  return (
    <div className="App">
      
      <RestaurantDetails/>
    </div>
  );
}

export default App;
